extends Node2D

enum Phase {
    DAY,
    NIGHT,
    VICTORY
}

const RESOURCE_NODE_SCENE := preload("res://scenes/resource_node.tscn")
const BUILD_SPOT_SCENE := preload("res://scenes/build_spot.tscn")
const ARCHER_TOWER_SCENE := preload("res://scenes/archer_tower.tscn")
const BARRICADE_SCENE := preload("res://scenes/barricade.tscn")
const BALLISTA_SCENE := preload("res://scenes/ballista.tscn")

const GRUNT_SCENE := preload("res://scenes/enemy.tscn")
const RUNNER_SCENE := preload("res://scenes/enemy_runner.tscn")
const BRUTE_SCENE := preload("res://scenes/enemy_brute.tscn")
const GRAVE_OX_SCENE := preload("res://scenes/grave_ox.tscn")
const SURVIVOR_SCENE := preload("res://scenes/survivor.tscn")
const GUARD_SCENE := preload("res://scenes/guard.tscn")
const ARCHER_SOLDIER_SCENE := preload("res://scenes/archer_soldier.tscn")
const VILLAGE_BUILD_SPOT_SCENE := preload("res://scenes/village_build_spot.tscn")
const HOUSE_SCENE := preload("res://scenes/house.tscn")
const FARM_SCENE := preload("res://scenes/farm.tscn")
const BARRACKS_BUILDING_SCENE := preload("res://scenes/barracks_building.tscn")
const BLACKSMITH_SCENE := preload("res://scenes/blacksmith.tscn")
const GATE_SCENE := preload("res://scenes/gate.tscn")
const WALL_SCENE := preload("res://scenes/wall.tscn")
const FOREST_ENEMY_SCENE := preload("res://scenes/forest_enemy.tscn")
const MINE_ENEMY_SCENE := preload("res://scenes/mine_enemy.tscn")
const RUINS_ENEMY_SCENE := preload("res://scenes/ruins_enemy.tscn")
const SHRINE_SCENE := preload("res://scenes/shrine.tscn")
const UI_STYLE := preload("res://scripts/ui_style.gd")

@export var day_duration: float = 45.0
@export var world_size: Vector2 = Vector2(2400, 1400)
@export var night_duration: float = 30.0
@export var nights_to_survive: int = 3
@export var final_boss_spawn_delay: float = 15.0

@onready var village_core: GloamVillageCore = $VillageCore as GloamVillageCore
@onready var phase_timer: Timer = $PhaseTimer
@onready var player: GloamPlayer = $Player as GloamPlayer

var world_camera: Camera2D

@onready var weapon_label: Label = $UI/StatsPanel/VBox/WeaponLabel
@onready var level_label: Label = $UI/StatsPanel/VBox/LevelLabel
@onready var xp_label: Label = $UI/StatsPanel/VBox/XPLabel
@onready var xp_bar: ProgressBar = $UI/StatsPanel/VBox/XPBar
@onready var hp_label: Label = $UI/StatsPanel/VBox/PlayerHPLabel
@onready var hp_bar: ProgressBar = $UI/StatsPanel/VBox/PlayerHPBar
@onready var damage_label: Label = $UI/StatsPanel/VBox/DamageLabel
@onready var speed_label: Label = $UI/StatsPanel/VBox/SpeedLabel
@onready var projectiles_label: Label = $UI/StatsPanel/VBox/ProjectilesLabel
@onready var core_hp_label: Label = $UI/StatsPanel/VBox/CoreHPLabel
@onready var core_hp_bar: ProgressBar = $UI/StatsPanel/VBox/CoreHPBar
@onready var controls_label: Label = $UI/StatsPanel/VBox/ControlsLabel

@onready var element_panel: PanelContainer = $UI/ElementPanel
@onready var fire_label: Label = $UI/ElementPanel/VBox/FireLabel
@onready var water_label: Label = $UI/ElementPanel/VBox/WaterLabel
@onready var earth_label: Label = $UI/ElementPanel/VBox/EarthLabel
@onready var air_label: Label = $UI/ElementPanel/VBox/AirLabel

@onready var wood_label: Label = $UI/ResourcePanel/VBox/WoodLabel
@onready var stone_label: Label = $UI/ResourcePanel/VBox/StoneLabel
@onready var iron_label: Label = $UI/ResourcePanel/VBox/IronLabel
@onready var food_label: Label = $UI/ResourcePanel/VBox/FoodLabel
@onready var essence_label: Label = $UI/ResourcePanel/VBox/EssenceLabel

@onready var population_panel: PanelContainer = $UI/PopulationPanel
@onready var population_label: Label = $UI/PopulationPanel/VBox/PopulationLabel
@onready var unassigned_label: Label = $UI/PopulationPanel/VBox/UnassignedLabel
@onready var workers_label: Label = $UI/PopulationPanel/VBox/WorkersLabel
@onready var guards_label: Label = $UI/PopulationPanel/VBox/GuardsLabel
@onready var archers_label: Label = $UI/PopulationPanel/VBox/ArchersLabel
@onready var assign_worker_button: Button = $UI/PopulationPanel/VBox/AssignWorkerButton
@onready var assign_guard_button: Button = $UI/PopulationPanel/VBox/AssignGuardButton
@onready var assign_archer_button: Button = $UI/PopulationPanel/VBox/AssignArcherButton

@onready var buildings_panel: PanelContainer = $UI/BuildingsPanel
@onready var houses_label: Label = $UI/BuildingsPanel/VBox/HousesLabel
@onready var farms_label: Label = $UI/BuildingsPanel/VBox/FarmsLabel
@onready var barracks_label: Label = $UI/BuildingsPanel/VBox/BarracksLabel
@onready var blacksmith_label: Label = $UI/BuildingsPanel/VBox/BlacksmithLabel
@onready var north_gate_label: Label = $UI/BuildingsPanel/VBox/NorthGateLabel
@onready var east_gate_label: Label = $UI/BuildingsPanel/VBox/EastGateLabel

@onready var fortification_panel: PanelContainer = $UI/FortificationPanel
@onready var fortification_prompt: Label = $UI/FortificationPanel/VBox/Prompt

@onready var shrine_panel: PanelContainer = $UI/ShrinePanel
@onready var shrine_prompt: Label = $UI/ShrinePanel/VBox/Prompt

@onready var phase_label: Label = $UI/PhasePanel/VBox/PhaseLabel
@onready var phase_time_label: Label = $UI/PhasePanel/VBox/PhaseTimeLabel
@onready var objective_label: Label = $UI/PhasePanel/VBox/ObjectiveLabel
@onready var wave_label: Label = $UI/PhasePanel/VBox/WaveLabel
@onready var zone_label: Label = $UI/PhasePanel/VBox/ZoneLabel

@onready var boss_panel: PanelContainer = $UI/BossPanel
@onready var boss_hp_label: Label = $UI/BossPanel/VBox/BossHPLabel

@onready var build_panel: PanelContainer = $UI/BuildPanel
@onready var build_prompt: Label = $UI/BuildPanel/VBox/Prompt

@onready var village_build_panel: PanelContainer = $UI/VillageBuildPanel
@onready var village_build_prompt: Label = $UI/VillageBuildPanel/VBox/Prompt

@onready var downed_label: Label = $UI/DownedLabel

@onready var weapon_panel: PanelContainer = $UI/WeaponPanel
@onready var sword_button: Button = $UI/WeaponPanel/VBox/SwordButton
@onready var bow_button: Button = $UI/WeaponPanel/VBox/BowButton
@onready var hammer_button: Button = $UI/WeaponPanel/VBox/HammerButton

@onready var level_up_panel: PanelContainer = $UI/LevelUpPanel
@onready var level_up_title: Label = $UI/LevelUpPanel/VBox/Title
@onready var upgrade_button_1: Button = $UI/LevelUpPanel/VBox/UpgradeButton1
@onready var upgrade_button_2: Button = $UI/LevelUpPanel/VBox/UpgradeButton2
@onready var upgrade_button_3: Button = $UI/LevelUpPanel/VBox/UpgradeButton3

@onready var game_over_panel: PanelContainer = $UI/GameOverPanel
@onready var restart_button: Button = $UI/GameOverPanel/VBox/RestartButton

@onready var victory_panel: PanelContainer = $UI/VictoryPanel
@onready var victory_restart_button: Button = $UI/VictoryPanel/VBox/RestartButton

@onready var dusk_tint: ColorRect = $UI/DuskTint
@onready var return_panel: PanelContainer = $UI/ReturnPanel
@onready var return_label: Label = $UI/ReturnPanel/ReturnLabel
@onready var modal_dimmer: ColorRect = $UI/ModalDimmer
@onready var toast_panel: PanelContainer = $UI/ToastPanel
@onready var toast_label: Label = $UI/ToastPanel/ToastLabel

var rng: RandomNumberGenerator = RandomNumberGenerator.new()

var pending_level_ups: int = 0

var controls_hint_time_left: float = 8.0
var dusk_warning_time: float = 12.0
var toast_tween: Tween

var wave_index: int = 0
var wave_active: bool = false
var wave_waiting: bool = false
var wave_token: int = 0
var game_over: bool = false
var run_started: bool = false

var current_phase: Phase = Phase.DAY
var current_day: int = 1
var completed_nights: int = 0

var wood: int = 0
var stone: int = 0
var iron: int = 0
var food: int = 3
var essence: int = 0

var houses: int = 0
var farms: int = 0
var farm_food_income: int = 0
var barracks_built: bool = false
var barracks_training_bonus: int = 0
var blacksmith_built: bool = false
var blacksmith_bonus_damage: int = 0

var total_population: int = 4
var unassigned_villagers: int = 0
var workers: int = 4
var guards: int = 0
var archers: int = 0
var population_capacity: int = 6

var active_build_spot: GloamBuildSpot = null
var active_village_build_spot: GloamVillageBuildSpot = null
var management_key_latched: bool = false

var current_boss: GloamGraveOx = null
var north_gate: GloamGate = null
var east_gate: GloamGate = null
var north_breach_marker: Node2D = null
var east_breach_marker: Node2D = null
var active_fortification: Node2D = null

var shrine_active: bool = false
var shrine_key_latched: bool = false
var shrine_night_guard_bonus: int = 0
var final_night_timer_expired: bool = false
var final_boss_defeated: bool = false

var current_upgrade_choices: Array[String] = []

var upgrade_pool: Array[Dictionary] = [
    {"id": "fire_kindling", "element": "FIRE", "name": "Kindling", "description": "Attacks ignite enemies."},
    {"id": "fire_lingering", "element": "FIRE", "name": "Lingering Flame", "description": "Burns last 1 extra tick."},
    {"id": "water_drench", "element": "WATER", "name": "Drench", "description": "Attacks slow enemies harder."},
    {"id": "water_deep_current", "element": "WATER", "name": "Deep Current", "description": "Slows last 1 second longer."},
    {"id": "earth_force", "element": "EARTH", "name": "Stone Force", "description": "Attacks knock enemies backward."},
    {"id": "earth_weight", "element": "EARTH", "name": "Heavy Core", "description": "More damage and knockback."},
    {"id": "air_tailwind", "element": "AIR", "name": "Tailwind", "description": "Weapon-specific speed bonus."},
    {"id": "air_quickening", "element": "AIR", "name": "Quickening", "description": "16% faster attacks."}
]

var resource_layout: Array[Dictionary] = [
    # Forest: mostly Wood
    {"type": "wood", "position": Vector2(720, 860)},
    {"type": "wood", "position": Vector2(850, 1010)},
    {"type": "wood", "position": Vector2(1000, 820)},
    {"type": "wood", "position": Vector2(1120, 1040)},
    {"type": "wood", "position": Vector2(760, 1210)},
    {"type": "wood", "position": Vector2(1010, 1260)},
    {"type": "wood", "position": Vector2(1220, 1160)},
    {"type": "wood", "position": Vector2(1250, 900)},

    # Mine: mostly Stone and Iron
    {"type": "stone", "position": Vector2(1570, 910)},
    {"type": "stone", "position": Vector2(1730, 1050)},
    {"type": "stone", "position": Vector2(1910, 920)},
    {"type": "stone", "position": Vector2(2110, 1120)},
    {"type": "stone", "position": Vector2(1840, 1260)},
    {"type": "iron", "position": Vector2(1660, 1190)},
    {"type": "iron", "position": Vector2(2020, 1010)},
    {"type": "iron", "position": Vector2(2190, 1240)},

    # Ruins: mixed rarer materials
    {"type": "stone", "position": Vector2(1420, 300)},
    {"type": "stone", "position": Vector2(1760, 480)},
    {"type": "iron", "position": Vector2(1570, 560)},
    {"type": "iron", "position": Vector2(2040, 350)}
]

var build_spot_layout: Array[Vector2] = [
    Vector2(150, 955),
    Vector2(270, 955),
    Vector2(390, 955),
    Vector2(535, 1050),
    Vector2(535, 1165),
    Vector2(535, 1280),
    Vector2(400, 1325)
]

var village_build_spot_layout: Array[Vector2] = [
    Vector2(125, 1080),
    Vector2(260, 1080),
    Vector2(395, 1080),
    Vector2(125, 1220),
    Vector2(260, 1220),
    Vector2(395, 1220)
]

var survivor_layout: Array[Vector2] = [
    Vector2(1160, 760),
    Vector2(2140, 1160),
    Vector2(1920, 300)
]

var guard_slots: Array[Vector2] = [
    Vector2(170, 1120),
    Vector2(350, 1120),
    Vector2(170, 1260),
    Vector2(350, 1260),
    Vector2(260, 1100),
    Vector2(260, 1300)
]

var archer_slots: Array[Vector2] = [
    Vector2(135, 1145),
    Vector2(385, 1145),
    Vector2(135, 1285),
    Vector2(385, 1285),
    Vector2(215, 1190),
    Vector2(305, 1190)
]


var forest_enemy_positions: Array[Vector2] = [
    Vector2(760, 900),
    Vector2(920, 1160),
    Vector2(1100, 940),
    Vector2(1230, 1220),
    Vector2(1280, 800)
]

var mine_enemy_positions: Array[Vector2] = [
    Vector2(1540, 880),
    Vector2(1770, 1180),
    Vector2(1980, 940),
    Vector2(2180, 1160),
    Vector2(2250, 850)
]

var ruins_enemy_positions: Array[Vector2] = [
    Vector2(1370, 280),
    Vector2(1620, 510),
    Vector2(1880, 260),
    Vector2(2160, 520)
]

func _ready() -> void:
    rng.randomize()

    phase_timer.one_shot = true
    phase_timer.timeout.connect(_on_phase_timer_timeout)

    player.xp_changed.connect(_update_xp_ui)
    player.leveled_up.connect(_on_player_leveled_up)
    player.health_changed.connect(_update_player_hp_ui)
    player.downed.connect(_on_player_downed)
    player.respawned.connect(_on_player_respawned)
    player.build_changed.connect(_update_build_ui)

    village_core.health_changed.connect(_update_core_hp_ui)
    village_core.destroyed.connect(_on_village_core_destroyed)

    sword_button.pressed.connect(func(): _choose_starting_weapon("sword"))
    bow_button.pressed.connect(func(): _choose_starting_weapon("bow"))
    hammer_button.pressed.connect(func(): _choose_starting_weapon("hammer"))

    assign_worker_button.pressed.connect(func(): _assign_villager("worker"))
    assign_guard_button.pressed.connect(func(): _assign_villager("guard"))
    assign_archer_button.pressed.connect(func(): _assign_villager("archer"))

    upgrade_button_1.pressed.connect(func(): _choose_upgrade(0))
    upgrade_button_2.pressed.connect(func(): _choose_upgrade(1))
    upgrade_button_3.pressed.connect(func(): _choose_upgrade(2))

    restart_button.pressed.connect(_restart_game)
    victory_restart_button.pressed.connect(_restart_game)

    level_up_panel.hide()
    game_over_panel.hide()
    victory_panel.hide()
    downed_label.hide()
    build_panel.hide()
    village_build_panel.hide()
    fortification_panel.hide()
    shrine_panel.hide()
    boss_panel.hide()
    return_panel.hide()
    population_panel.hide()
    buildings_panel.hide()
    element_panel.hide()
    dusk_tint.color = Color(0, 0, 0, 0)

    _spawn_build_spots()
    _spawn_village_build_spots()
    _spawn_shrine()
    _spawn_corner_fortifications()

    _update_xp_ui(player.xp, player.xp_to_next, player.level)
    _update_player_hp_ui(player.hp, player.max_hp)
    _update_build_ui()
    _update_core_hp_ui(village_core.hp, village_core.max_hp)
    _apply_ui_style()
    _configure_interactive_controls()
    toast_panel.hide()
    _update_resource_ui()
    _update_population_ui()
    _update_buildings_ui()

    _setup_world_camera()
    _open_weapon_choice()



func _apply_ui_style() -> void:
    var theme_resource: Theme = UI_STYLE.create_theme()

    for child: Node in $UI.get_children():
        if child is Control:
            var control: Control = child as Control
            control.theme = theme_resource

    hp_bar.add_theme_stylebox_override(
        "fill",
        UI_STYLE.make_progress_fill(Color(0.72, 0.19, 0.16, 1.0))
    )
    xp_bar.add_theme_stylebox_override(
        "fill",
        UI_STYLE.make_progress_fill(Color(0.48, 0.60, 0.88, 1.0))
    )
    core_hp_bar.add_theme_stylebox_override(
        "fill",
        UI_STYLE.make_progress_fill(Color(0.82, 0.59, 0.20, 1.0))
    )

    weapon_panel.add_theme_stylebox_override(
        "panel",
        UI_STYLE.make_modal_panel_style()
    )
    level_up_panel.add_theme_stylebox_override(
        "panel",
        UI_STYLE.make_modal_panel_style()
    )
    game_over_panel.add_theme_stylebox_override(
        "panel",
        UI_STYLE.make_modal_panel_style()
    )
    victory_panel.add_theme_stylebox_override(
        "panel",
        UI_STYLE.make_modal_panel_style()
    )
    return_panel.add_theme_stylebox_override(
        "panel",
        UI_STYLE.make_alert_panel_style()
    )


func _show_modal_dimmer() -> void:
    modal_dimmer.show()


func _hide_modal_dimmer() -> void:
    modal_dimmer.hide()



func _configure_interactive_controls() -> void:
    _configure_buttons_recursive($UI)

    sword_button.tooltip_text = "Fast melee cleave. Strong close-range control."
    bow_button.tooltip_text = "Safe ranged weapon with reliable precision."
    hammer_button.tooltip_text = "Slow, heavy area attacks with strong knockback."

    assign_worker_button.tooltip_text = "Assign one available villager. Workers generate resources each dawn."
    assign_guard_button.tooltip_text = "Requires a Barracks. Guards defend the village in melee."
    assign_archer_button.tooltip_text = "Requires a Barracks. Archers defend from long range."

    restart_button.tooltip_text = "Restart the current run."
    victory_restart_button.tooltip_text = "Start a new run."


func _configure_buttons_recursive(root: Node) -> void:
    for child: Node in root.get_children():
        if child is BaseButton:
            var button: BaseButton = child as BaseButton
            button.focus_mode = Control.FOCUS_ALL
            button.mouse_default_cursor_shape = (
                Control.CURSOR_ARROW
                if button.disabled
                else Control.CURSOR_POINTING_HAND
            )

            var minimum_size: Vector2 = button.custom_minimum_size
            minimum_size.y = maxf(minimum_size.y, 42.0)
            button.custom_minimum_size = minimum_size

        _configure_buttons_recursive(child)


func _refresh_button_cursor(button: BaseButton) -> void:
    button.mouse_default_cursor_shape = (
        Control.CURSOR_ARROW
        if button.disabled
        else Control.CURSOR_POINTING_HAND
    )


func _show_toast(message: String, tone: String = "info") -> void:
    if is_instance_valid(toast_tween):
        toast_tween.kill()

    toast_label.text = message
    toast_panel.add_theme_stylebox_override(
        "panel",
        UI_STYLE.make_toast_panel_style(tone)
    )

    toast_panel.modulate = Color(1, 1, 1, 0)
    toast_panel.show()

    toast_tween = create_tween()
    toast_tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
    toast_tween.tween_property(
        toast_panel,
        "modulate",
        Color.WHITE,
        0.12
    )
    toast_tween.tween_interval(1.45)
    toast_tween.tween_property(
        toast_panel,
        "modulate",
        Color(1, 1, 1, 0),
        0.22
    )
    toast_tween.tween_callback(Callable(toast_panel, "hide"))


func _setup_world_camera() -> void:
    world_camera = Camera2D.new()
    world_camera.name = "WorldCamera"
    world_camera.position_smoothing_enabled = true
    world_camera.position_smoothing_speed = 7.0
    world_camera.limit_left = 0
    world_camera.limit_top = 0
    world_camera.limit_right = int(world_size.x)
    world_camera.limit_bottom = int(world_size.y)
    player.add_child(world_camera)
    world_camera.make_current()


func _clamp_player_to_world() -> void:
    player.global_position.x = clampf(player.global_position.x, 20.0, world_size.x - 20.0)
    player.global_position.y = clampf(player.global_position.y, 20.0, world_size.y - 20.0)


func _open_weapon_choice() -> void:
    run_started = false

    phase_label.text = "GLOAM"
    phase_time_label.text = "--"
    objective_label.text = "Choose your starting weapon"

    _show_modal_dimmer()
    weapon_panel.show()
    sword_button.grab_focus()
    get_tree().paused = true


func _choose_starting_weapon(weapon: String) -> void:
    player.choose_weapon(weapon)
    weapon_panel.hide()
    _hide_modal_dimmer()

    get_tree().paused = false
    run_started = true

    _update_build_ui()
    _start_day()


func _process(_delta: float) -> void:
    if not run_started or game_over or current_phase == Phase.VICTORY:
        return

    _clamp_player_to_world()
    _update_zone_status()
    _update_contextual_hud()
    _update_dusk_guidance()

    if controls_hint_time_left > 0.0:
        controls_hint_time_left = maxf(0.0, controls_hint_time_left - _delta)
        controls_label.visible = controls_hint_time_left > 0.0

    if phase_timer.time_left > 0.0:
        phase_time_label.text = "%02d" % int(ceil(phase_timer.time_left))
    elif final_night_timer_expired and not final_boss_defeated:
        phase_time_label.text = "BOSS"

    if current_phase == Phase.DAY:
        _update_fortification_interaction()
    else:
        active_fortification = null
        fortification_panel.hide()
        shrine_panel.hide()

    var shrine_pressed: bool = (
        Input.is_key_pressed(KEY_H)
        or Input.is_key_pressed(KEY_B)
        or Input.is_key_pressed(KEY_E)
    )

    if not shrine_pressed:
        shrine_key_latched = false
    elif shrine_active and not shrine_key_latched and current_phase == Phase.DAY:
        shrine_key_latched = true

        if Input.is_key_pressed(KEY_H):
            _buy_shrine_heal()
        elif Input.is_key_pressed(KEY_B):
            _buy_shrine_blessing()
        elif Input.is_key_pressed(KEY_E):
            _buy_shrine_ward()

    if current_phase == Phase.DAY and is_instance_valid(active_build_spot):
        if not active_build_spot.occupied:
            if Input.is_key_pressed(KEY_1):
                _try_build("archer")
            elif Input.is_key_pressed(KEY_2):
                _try_build("barricade")
            elif Input.is_key_pressed(KEY_3):
                _try_build("ballista")

    if current_phase == Phase.DAY and is_instance_valid(active_village_build_spot):
        if not active_village_build_spot.occupied:
            if Input.is_key_pressed(KEY_4):
                _try_build_village_building("house")
            elif Input.is_key_pressed(KEY_5):
                _try_build_village_building("farm")
            elif Input.is_key_pressed(KEY_6):
                _try_build_village_building("barracks")
            elif Input.is_key_pressed(KEY_7):
                _try_build_village_building("blacksmith")

    var management_pressed: bool = Input.is_key_pressed(KEY_R) or Input.is_key_pressed(KEY_U)

    if not management_pressed:
        management_key_latched = false
    elif not management_key_latched and current_phase == Phase.DAY:
        management_key_latched = true

        if is_instance_valid(active_fortification):
            if Input.is_key_pressed(KEY_R):
                _repair_fortification()
            elif Input.is_key_pressed(KEY_U):
                _upgrade_fortification()

        elif is_instance_valid(active_build_spot) and active_build_spot.occupied:
            if Input.is_key_pressed(KEY_R):
                _repair_defense()
            elif Input.is_key_pressed(KEY_U):
                _upgrade_defense()

        elif is_instance_valid(active_village_build_spot) and active_village_build_spot.occupied:
            if Input.is_key_pressed(KEY_R):
                _repair_village_building()
            elif Input.is_key_pressed(KEY_U):
                _upgrade_village_building()



func _is_player_in_village() -> bool:
    var p: Vector2 = player.global_position
    return p.x <= 580.0 and p.y >= 900.0


func _update_contextual_hud() -> void:
    var in_village: bool = _is_player_in_village()

    # Elemental panel only occupies screen space once it contains information.
    element_panel.visible = (
        player.fire_level
        + player.water_level
        + player.earth_level
        + player.air_level
    ) > 0

    if current_phase == Phase.DAY:
        population_panel.visible = in_village
        buildings_panel.visible = in_village

        houses_label.show()
        farms_label.show()
        barracks_label.show()
        blacksmith_label.show()
    else:
        # Night HUD cares about fortification health, not management.
        population_panel.hide()
        buildings_panel.show()

        houses_label.hide()
        farms_label.hide()
        barracks_label.hide()
        blacksmith_label.hide()

    north_gate_label.show()
    east_gate_label.show()


func _update_dusk_guidance() -> void:
    if current_phase != Phase.DAY:
        dusk_tint.color = Color(0.04, 0.07, 0.14, 0.10)
        return_panel.hide()
        return

    var time_left: float = phase_timer.time_left

    if time_left <= 15.0:
        var urgency: float = clampf((15.0 - time_left) / 15.0, 0.0, 1.0)
        dusk_tint.color = Color(0.30, 0.07, 0.04, 0.04 + urgency * 0.13)
    else:
        dusk_tint.color = Color(0, 0, 0, 0)

    if time_left <= dusk_warning_time:
        phase_label.text = "DUSK"

        if not _is_player_in_village():
            var delta_to_village: Vector2 = village_core.global_position - player.global_position
            var distance: int = int(round(delta_to_village.length()))
            var arrow: String = _direction_arrow(delta_to_village)

            return_label.text = "%s  RETURN TO VILLAGE  •  %d" % [
                arrow,
                distance
            ]
            return_panel.show()
            objective_label.text = "Night is coming. Get behind the walls."
        else:
            return_panel.hide()
            objective_label.text = "Dusk. Finish preparations."
    else:
        phase_label.text = "DAY %d" % current_day
        return_panel.hide()


func _direction_arrow(direction: Vector2) -> String:
    if direction.length_squared() <= 1.0:
        return "•"

    var angle: float = direction.angle()
    var eighth: float = PI / 8.0

    if angle >= -eighth and angle < eighth:
        return "→"
    if angle >= eighth and angle < 3.0 * eighth:
        return "↘"
    if angle >= 3.0 * eighth and angle < 5.0 * eighth:
        return "↓"
    if angle >= 5.0 * eighth and angle < 7.0 * eighth:
        return "↙"
    if angle >= 7.0 * eighth or angle < -7.0 * eighth:
        return "←"
    if angle >= -7.0 * eighth and angle < -5.0 * eighth:
        return "↖"
    if angle >= -5.0 * eighth and angle < -3.0 * eighth:
        return "↑"

    return "↗"


func _set_camera_zoom(target_zoom: Vector2) -> void:
    if not is_instance_valid(world_camera):
        return

    var tween: Tween = create_tween()
    tween.set_trans(Tween.TRANS_QUAD)
    tween.set_ease(Tween.EASE_OUT)
    tween.tween_property(world_camera, "zoom", target_zoom, 0.35)


func _start_day() -> void:
    current_phase = Phase.DAY

    wave_token += 1
    wave_active = false
    wave_waiting = false
    wave_index = 0

    _clear_all_enemies()
    _clear_day_enemies()
    _spawn_day_resources()
    _spawn_survivors()
    _spawn_day_enemies()

    if current_day > 1:
        _apply_worker_income()

    boss_panel.hide()
    current_boss = null
    final_night_timer_expired = false
    final_boss_defeated = false

    phase_label.text = "DAY %d" % current_day
    objective_label.text = "Explore, gather, rescue, then return before dusk"
    wave_label.text = "No assault"
    zone_label.text = "VILLAGE • Safe"

    controls_hint_time_left = 6.0
    controls_label.show()
    return_panel.hide()
    _set_camera_zoom(Vector2(1.0, 1.0))
    _update_population_ui()
    _update_contextual_hud()
    phase_timer.start(day_duration)


func _start_night() -> void:
    current_phase = Phase.NIGHT

    _clear_day_resources()
    _clear_survivors()
    _clear_day_enemies()
    build_panel.hide()
    village_build_panel.hide()
    fortification_panel.hide()
    shrine_panel.hide()
    shrine_active = false
    active_fortification = null
    active_build_spot = null
    active_village_build_spot = null
    _update_population_ui()

    _apply_shrine_ward_to_fortifications()

    phase_label.text = "NIGHT %d" % current_day
    objective_label.text = "Prepare for the first assault"
    wave_label.text = "Assaults incoming"

    return_panel.hide()
    _set_camera_zoom(Vector2(0.84, 0.84))
    _update_contextual_hud()
    phase_timer.start(night_duration)

    wave_token += 1
    wave_index = 0
    wave_active = false
    wave_waiting = false

    _start_next_wave(wave_token)


func _get_wave_plan() -> Array[Dictionary]:
    match current_day:
        1:
            return [
                {"lane": "north", "count": 5, "gap": 0.45, "warning": "NORTH ASSAULT"},
                {"lane": "east", "count": 6, "gap": 0.42, "warning": "EAST ASSAULT"},
                {"lane": "split", "count": 8, "gap": 0.38, "warning": "SPLIT ASSAULT"}
            ]

        2:
            return [
                {"lane": "east", "count": 7, "gap": 0.36, "warning": "RUNNERS AT THE EAST GATE"},
                {"lane": "north", "count": 8, "gap": 0.34, "warning": "NORTH PRESSURE"},
                {"lane": "split", "count": 10, "gap": 0.30, "warning": "BOTH GATES UNDER ATTACK"},
                {"lane": "north", "count": 8, "gap": 0.28, "warning": "FINAL NORTH PUSH"}
            ]

        _:
            return [
                {"lane": "north", "count": 8, "gap": 0.30, "warning": "HEAVY NORTH ASSAULT"},
                {"lane": "east", "count": 8, "gap": 0.28, "warning": "HEAVY EAST ASSAULT"},
                {"lane": "split", "count": 12, "gap": 0.25, "warning": "THE HORDE SURGES"},
                {"lane": "boss", "count": 1, "gap": 0.0, "warning": "THE GRAVE OX APPROACHES"}
            ]


func _start_next_wave(token: int) -> void:
    if token != wave_token or game_over or current_phase != Phase.NIGHT:
        return

    var plan: Array[Dictionary] = _get_wave_plan()

    if wave_index >= plan.size():
        wave_label.text = "No more assaults"
        objective_label.text = "Hold until dawn"
        wave_active = false
        return

    var wave: Dictionary = plan[wave_index]
    wave_waiting = true
    wave_active = false

    wave_label.text = "Wave %d / %d" % [wave_index + 1, plan.size()]
    objective_label.text = wave["warning"]

    await get_tree().create_timer(2.5).timeout

    if token != wave_token or game_over or current_phase != Phase.NIGHT:
        return

    wave_waiting = false
    wave_active = true

    if wave["lane"] == "boss":
        _spawn_grave_ox()
    else:
        await _run_enemy_wave(wave, token)

    if token != wave_token or game_over or current_phase != Phase.NIGHT:
        return

    wave_active = false
    wave_index += 1

    if wave_index < plan.size():
        wave_label.text = "Breathing room"
        objective_label.text = "Regroup"
        await get_tree().create_timer(3.0).timeout

        if token != wave_token or game_over or current_phase != Phase.NIGHT:
            return

        _start_next_wave(token)
    else:
        wave_label.text = "Final assault complete"
        objective_label.text = "Hold until dawn"


func _run_enemy_wave(wave: Dictionary, token: int) -> void:
    var count: int = wave["count"]
    var gap: float = wave["gap"]
    var lane: String = wave["lane"]

    for i in range(count):
        if token != wave_token or game_over or current_phase != Phase.NIGHT:
            return

        var spawn_lane: String = lane

        if lane == "split":
            spawn_lane = "north" if i % 2 == 0 else "east"

        _spawn_enemy_in_lane(spawn_lane)

        if gap > 0.0 and i < count - 1:
            await get_tree().create_timer(gap).timeout


func _spawn_enemy_in_lane(lane: String) -> void:
    if game_over or current_phase != Phase.NIGHT:
        return

    var chosen_scene: PackedScene = _choose_enemy_scene()
    var enemy: GloamEnemy = chosen_scene.instantiate() as GloamEnemy

    if lane == "north":
        enemy.global_position = Vector2(rng.randf_range(215.0, 305.0), 700.0)
    else:
        enemy.global_position = Vector2(820.0, rng.randf_range(1145.0, 1235.0))

    if enemy.has_method("set_targets"):
        enemy.set_targets(village_core, player)

    if enemy.has_method("set_lane"):
        if lane == "north":
            enemy.set_lane(north_gate, north_breach_marker)
        else:
            enemy.set_lane(east_gate, east_breach_marker)

    $Enemies.add_child(enemy)


func _finish_night() -> void:
    wave_token += 1
    wave_active = false
    wave_waiting = false

    if current_day == nights_to_survive:
        final_night_timer_expired = true

        if final_boss_defeated:
            _win_run()
        else:
            objective_label.text = "Defeat the Grave Ox"
            wave_label.text = "Final boss"
            phase_time_label.text = "BOSS"

        return

    completed_nights += 1
    current_day += 1
    _start_day()


func _on_phase_timer_timeout() -> void:
    if game_over:
        return

    match current_phase:
        Phase.DAY:
            _start_night()
        Phase.NIGHT:
            _finish_night()


func _spawn_grave_ox() -> void:
    if game_over or current_phase != Phase.NIGHT or current_day != nights_to_survive:
        return

    if is_instance_valid(current_boss):
        return

    var boss: GloamGraveOx = GRAVE_OX_SCENE.instantiate() as GloamGraveOx
    boss.global_position = Vector2(260, 670)
    boss.set_targets(village_core, player)
    boss.set_lane(north_gate, north_breach_marker)

    boss.health_changed.connect(_update_boss_hp)
    boss.defeated.connect(_on_grave_ox_defeated)

    $Enemies.add_child(boss)
    current_boss = boss

    boss_panel.show()
    boss_hp_label.text = "Grave Ox: %d / %d" % [boss.max_hp, boss.max_hp]
    objective_label.text = "GRAVE OX HAS ARRIVED"


func _update_boss_hp(current_hp: int, max_hp: int) -> void:
    boss_hp_label.text = "Grave Ox: %d / %d" % [current_hp, max_hp]


func _on_grave_ox_defeated() -> void:
    final_boss_defeated = true
    current_boss = null
    boss_panel.hide()

    if final_night_timer_expired:
        _win_run()
    else:
        objective_label.text = "The Grave Ox is dead. Hold until dawn."
        wave_label.text = "Boss defeated"




func _spawn_corner_fortifications() -> void:
    north_breach_marker = Marker2D.new()
    north_breach_marker.name = "NorthBreachMarker"
    north_breach_marker.position = Vector2(260, 1015)
    north_breach_marker.add_to_group("lane_markers")
    $LaneMarkers.add_child(north_breach_marker)

    east_breach_marker = Marker2D.new()
    east_breach_marker.name = "EastBreachMarker"
    east_breach_marker.position = Vector2(525, 1190)
    east_breach_marker.add_to_group("lane_markers")
    $LaneMarkers.add_child(east_breach_marker)

    var north_index: int = 1

    for x in [70, 120, 170, 350, 400, 450]:
        var wall: GloamWall = WALL_SCENE.instantiate() as GloamWall
        wall.wall_name = "North Wall %d" % north_index
        wall.position = Vector2(x, 995)
        $Walls.add_child(wall)
        north_index += 1

    var east_index: int = 1

    for y in [1035, 1085, 1135, 1245, 1295, 1345]:
        var wall: GloamWall = WALL_SCENE.instantiate() as GloamWall
        wall.wall_name = "East Wall %d" % east_index
        wall.position = Vector2(505, y)
        wall.rotation = PI / 2.0
        $Walls.add_child(wall)
        east_index += 1

    north_gate = GATE_SCENE.instantiate() as GloamGate
    north_gate.gate_name = "North Gate"
    north_gate.position = Vector2(260, 995)
    north_gate.health_changed.connect(_update_north_gate_ui)
    north_gate.destroyed.connect(_on_gate_destroyed)
    $Gates.add_child(north_gate)

    east_gate = GATE_SCENE.instantiate() as GloamGate
    east_gate.gate_name = "East Gate"
    east_gate.position = Vector2(505, 1190)
    east_gate.rotation = PI / 2.0
    east_gate.health_changed.connect(_update_east_gate_ui)
    east_gate.destroyed.connect(_on_gate_destroyed)
    $Gates.add_child(east_gate)

    _update_north_gate_ui(north_gate.hp, north_gate.max_hp)
    _update_east_gate_ui(east_gate.hp, east_gate.max_hp)


func _update_north_gate_ui(current_hp: int, max_hp: int) -> void:
    var state: String = ""

    if is_instance_valid(north_gate) and north_gate.is_breached:
        state = " BREACHED"

    north_gate_label.text = "North Gate Lv.%d: %d / %d%s" % [
        north_gate.level if is_instance_valid(north_gate) else 1,
        current_hp,
        max_hp,
        state
    ]


func _update_east_gate_ui(current_hp: int, max_hp: int) -> void:
    var state: String = ""

    if is_instance_valid(east_gate) and east_gate.is_breached:
        state = " BREACHED"

    east_gate_label.text = "East Gate Lv.%d: %d / %d%s" % [
        east_gate.level if is_instance_valid(east_gate) else 1,
        current_hp,
        max_hp,
        state
    ]


func _on_gate_destroyed(gate: Node) -> void:
    if gate == north_gate:
        _update_north_gate_ui(0, gate.max_hp)
    elif gate == east_gate:
        _update_east_gate_ui(0, gate.max_hp)

    objective_label.text = "%s has been breached!" % gate.gate_name
    _show_toast("%s BREACHED" % gate.gate_name.to_upper(), "danger")


func _update_fortification_interaction() -> void:
    var nearest: Node2D = null
    var nearest_distance: float = 72.0

    for gate in $Gates.get_children():
        if not is_instance_valid(gate):
            continue

        var d: float = player.global_position.distance_to(gate.global_position)

        if d < nearest_distance:
            nearest = gate
            nearest_distance = d

    for wall in $Walls.get_children():
        if not is_instance_valid(wall):
            continue

        var d: float = player.global_position.distance_to(wall.global_position)

        if d < nearest_distance:
            nearest = wall
            nearest_distance = d

    active_fortification = nearest

    if is_instance_valid(active_fortification):
        _refresh_fortification_prompt()
        fortification_panel.show()
    else:
        fortification_panel.hide()


func _refresh_fortification_prompt() -> void:
    if not is_instance_valid(active_fortification):
        return

    var label: String = "Fortification"
    var hp: int = int(active_fortification.get("hp"))
    var max_hp: int = int(active_fortification.get("max_hp"))
    var level: int = int(active_fortification.get("level"))
    var breached: bool = bool(active_fortification.get("is_breached"))
    var repair_cost: String = "[1 Wood + 1 Stone]"
    var upgrade_cost: String = "[1 Wood + 2 Stone]"

    if active_fortification.is_in_group("gates"):
        label = active_fortification.gate_name
        repair_cost = "[2 Wood + 2 Stone]" if breached else "[2 Wood + 1 Stone]"
        upgrade_cost = "[2 Wood + 3 Stone + 1 Iron]"
    else:
        label = active_fortification.wall_name
        repair_cost = "[1 Wood + 2 Stone]" if breached else "[1 Wood + 1 Stone]"

    var repair_text: String = "R Repair %s" % repair_cost

    if breached:
        repair_text = "R REBUILD %s" % repair_cost
    elif hp >= max_hp:
        repair_text = "R Repair  [FULL HP]"

    var upgrade_text: String = "MAX LEVEL"

    if bool(active_fortification.call("can_upgrade")):
        upgrade_text = "U Upgrade %s" % upgrade_cost
    elif breached:
        upgrade_text = "Repair before upgrading"

    fortification_prompt.text = (
        "%s  Lv.%d\nHP: %d / %d\n%s\n%s"
        % [label, level, hp, max_hp, repair_text, upgrade_text]
    )


func _repair_fortification() -> void:
    if not is_instance_valid(active_fortification):
        return

    if not bool(active_fortification.get("is_breached")) and int(active_fortification.get("hp")) >= int(active_fortification.get("max_hp")):
        _refresh_fortification_prompt()
        return

    var cost_wood: int = 1
    var cost_stone: int = 1

    if active_fortification.is_in_group("gates"):
        cost_wood = 2
        cost_stone = 2 if bool(active_fortification.get("is_breached")) else 1
    elif bool(active_fortification.get("is_breached")):
        cost_stone = 2

    if wood < cost_wood or stone < cost_stone:
        fortification_prompt.text = "NOT ENOUGH RESOURCES TO REPAIR"
        return

    wood -= cost_wood
    stone -= cost_stone
    active_fortification.call("repair_full")

    _update_resource_ui()

    if active_fortification == north_gate:
        _update_north_gate_ui(north_gate.hp, north_gate.max_hp)
    elif active_fortification == east_gate:
        _update_east_gate_ui(east_gate.hp, east_gate.max_hp)

    _refresh_fortification_prompt()


func _upgrade_fortification() -> void:
    if not is_instance_valid(active_fortification):
        return

    if not bool(active_fortification.call("can_upgrade")):
        _refresh_fortification_prompt()
        return

    var cost_wood: int = 1
    var cost_stone: int = 2
    var cost_iron: int = 0

    if active_fortification.is_in_group("gates"):
        cost_wood = 2
        cost_stone = 3
        cost_iron = 1

    if wood < cost_wood or stone < cost_stone or iron < cost_iron:
        fortification_prompt.text = "NOT ENOUGH RESOURCES TO UPGRADE"
        return

    wood -= cost_wood
    stone -= cost_stone
    iron -= cost_iron

    active_fortification.call("upgrade")
    _update_resource_ui()

    if active_fortification == north_gate:
        _update_north_gate_ui(north_gate.hp, north_gate.max_hp)
    elif active_fortification == east_gate:
        _update_east_gate_ui(east_gate.hp, east_gate.max_hp)

    _refresh_fortification_prompt()


func _spawn_village_build_spots() -> void:
    for pos in village_build_spot_layout:
        var spot: GloamVillageBuildSpot = VILLAGE_BUILD_SPOT_SCENE.instantiate() as GloamVillageBuildSpot
        spot.position = pos
        $VillageBuildSpots.add_child(spot)


func set_active_village_build_spot(spot: GloamVillageBuildSpot) -> void:
    if current_phase != Phase.DAY:
        return

    active_village_build_spot = spot

    if spot.occupied and is_instance_valid(spot.building):
        _refresh_village_management_prompt()
    else:
        village_build_prompt.text = (
            "VILLAGE BUILDING\n"
            + "4 House       [3 Wood]  +3 population capacity\n"
            + "5 Farm        [2 Wood + 1 Stone]  +3 Food each dawn\n"
            + "6 Barracks    [3 Wood + 2 Stone]  unlock Guards/Archers\n"
            + "7 Blacksmith  [2 Wood + 1 Stone + 2 Iron]  +1 hero/soldier damage"
        )

    village_build_panel.show()


func clear_active_village_build_spot(spot: GloamVillageBuildSpot) -> void:
    if active_village_build_spot == spot:
        active_village_build_spot = null
        village_build_panel.hide()


func _try_build_village_building(kind: String) -> void:
    if current_phase != Phase.DAY or not is_instance_valid(active_village_build_spot):
        return

    if active_village_build_spot.occupied:
        return

    var scene: PackedScene = null
    var cost_wood: int = 0
    var cost_stone: int = 0
    var cost_iron: int = 0

    match kind:
        "house":
            scene = HOUSE_SCENE
            cost_wood = 3

        "farm":
            scene = FARM_SCENE
            cost_wood = 2
            cost_stone = 1

        "barracks":
            if barracks_built:
                village_build_prompt.text = "BARRACKS ALREADY BUILT"
                _show_toast("Barracks already built", "warning")
                return

            scene = BARRACKS_BUILDING_SCENE
            cost_wood = 3
            cost_stone = 2

        "blacksmith":
            if blacksmith_built:
                village_build_prompt.text = "BLACKSMITH ALREADY BUILT"
                _show_toast("Blacksmith already built", "warning")
                return

            scene = BLACKSMITH_SCENE
            cost_wood = 2
            cost_stone = 1
            cost_iron = 2

        _:
            return

    if wood < cost_wood or stone < cost_stone or iron < cost_iron:
        village_build_prompt.text = "NOT ENOUGH RESOURCES"
        _show_toast("Not enough resources", "warning")
        return

    wood -= cost_wood
    stone -= cost_stone
    iron -= cost_iron

    var building: GloamVillageBuilding = scene.instantiate() as GloamVillageBuilding
    building.global_position = active_village_build_spot.global_position
    building.destroyed.connect(_on_village_building_destroyed)
    $VillageBuildings.add_child(building)

    match kind:
        "house":
            houses += 1
            population_capacity += 3

        "farm":
            farms += 1
            farm_food_income += 3

        "barracks":
            barracks_built = true

        "blacksmith":
            blacksmith_built = true
            blacksmith_bonus_damage += 1
            player.apply_blacksmith_bonus(1)

            for soldier in $Soldiers.get_children():
                soldier.attack_damage += 1

    active_village_build_spot.assign_building(building, kind)
    active_village_build_spot = null

    village_build_panel.hide()

    _update_resource_ui()
    _update_population_ui()
    _update_buildings_ui()
    _show_toast("%s built" % kind.to_upper(), "success")


func _spawn_build_spots() -> void:
    for pos in build_spot_layout:
        var spot: GloamBuildSpot = BUILD_SPOT_SCENE.instantiate() as GloamBuildSpot
        spot.position = pos
        $BuildSpots.add_child(spot)


func set_active_build_spot(spot: GloamBuildSpot) -> void:
    if current_phase != Phase.DAY:
        return

    active_build_spot = spot

    if spot.occupied and is_instance_valid(spot.structure):
        _refresh_defense_management_prompt()
    else:
        build_prompt.text = (
            "BUILD SPOT\n"
            + "1 Archer Tower  [3 Wood]\n"
            + "2 Barricade     [2 Wood + 1 Stone]\n"
            + "3 Ballista      [2 Wood + 2 Iron]"
        )

    build_panel.show()


func clear_active_build_spot(spot: GloamBuildSpot) -> void:
    if active_build_spot == spot:
        active_build_spot = null
        build_panel.hide()


func _try_build(kind: String) -> void:
    if current_phase != Phase.DAY or not is_instance_valid(active_build_spot):
        return

    if active_build_spot.occupied:
        return

    var scene: PackedScene = null
    var cost_wood: int = 0
    var cost_stone: int = 0
    var cost_iron: int = 0

    match kind:
        "archer":
            scene = ARCHER_TOWER_SCENE
            cost_wood = 3

        "barricade":
            scene = BARRICADE_SCENE
            cost_wood = 2
            cost_stone = 1

        "ballista":
            scene = BALLISTA_SCENE
            cost_wood = 2
            cost_iron = 2

        _:
            return

    if wood < cost_wood or stone < cost_stone or iron < cost_iron:
        build_prompt.text = "NOT ENOUGH RESOURCES"
        _show_toast("Not enough resources", "warning")
        return

    wood -= cost_wood
    stone -= cost_stone
    iron -= cost_iron

    var defense: GloamDefense = scene.instantiate() as GloamDefense
    defense.global_position = active_build_spot.global_position
    $Defenses.add_child(defense)

    active_build_spot.assign_structure(defense, kind)
    active_build_spot = null

    build_panel.hide()
    _update_resource_ui()
    _show_toast("%s built" % kind.to_upper(), "success")



func _refresh_defense_management_prompt() -> void:
    if not is_instance_valid(active_build_spot) or not active_build_spot.occupied:
        return

    var defense = active_build_spot.structure

    if not is_instance_valid(defense):
        return

    var upgrade_text: String = "MAX LEVEL"

    if defense.can_upgrade():
        upgrade_text = "U Upgrade  [2 Wood + 1 Stone + 1 Iron]"

    build_prompt.text = (
        "%s  Lv.%d\nHP: %d / %d\n"
        % [defense.defense_name, defense.level, defense.hp, defense.max_hp]
        + "R Repair   [1 Wood + 1 Stone]\n"
        + upgrade_text
    )


func _repair_defense() -> void:
    if not is_instance_valid(active_build_spot) or not active_build_spot.occupied:
        return

    var defense = active_build_spot.structure

    if not is_instance_valid(defense):
        return

    if defense.hp >= defense.max_hp:
        build_prompt.text = "%s is already fully repaired." % defense.defense_name
        _show_toast("Already at full health", "info")
        return

    if wood < 1 or stone < 1:
        build_prompt.text = "NOT ENOUGH RESOURCES FOR REPAIR"
        _show_toast("Not enough resources to repair", "warning")
        return

    wood -= 1
    stone -= 1
    defense.repair_full()

    _update_resource_ui()
    _refresh_defense_management_prompt()
    _show_toast("%s repaired" % defense.defense_name, "success")


func _upgrade_defense() -> void:
    if not is_instance_valid(active_build_spot) or not active_build_spot.occupied:
        return

    var defense = active_build_spot.structure

    if not is_instance_valid(defense):
        return

    if not defense.can_upgrade():
        build_prompt.text = "%s IS MAX LEVEL" % defense.defense_name
        _show_toast("Already at maximum level", "info")
        return

    if wood < 2 or stone < 1 or iron < 1:
        build_prompt.text = "NOT ENOUGH RESOURCES FOR UPGRADE"
        _show_toast("Not enough resources to upgrade", "warning")
        return

    wood -= 2
    stone -= 1
    iron -= 1
    defense.upgrade()

    _update_resource_ui()
    _refresh_defense_management_prompt()
    _show_toast("%s upgraded to Lv.%d" % [defense.defense_name, defense.level], "success")


func _refresh_village_management_prompt() -> void:
    if not is_instance_valid(active_village_build_spot) or not active_village_build_spot.occupied:
        return

    var building = active_village_build_spot.building

    if not is_instance_valid(building):
        return

    var upgrade_text: String = "MAX LEVEL"

    if building.can_upgrade():
        upgrade_text = "U Upgrade  %s" % _village_upgrade_cost_text(building.building_type)

    village_build_prompt.text = (
        "%s  Lv.%d\nHP: %d / %d\n"
        % [building.display_name, building.level, building.hp, building.max_hp]
        + "R Repair   [1 Wood + 1 Stone]\n"
        + upgrade_text
    )


func _village_upgrade_cost_text(kind: String) -> String:
    match kind:
        "house":
            return "[2 Wood + 1 Stone]"
        "farm":
            return "[2 Wood + 1 Stone]"
        "barracks":
            return "[2 Wood + 2 Stone + 1 Iron]"
        "blacksmith":
            return "[1 Wood + 1 Stone + 2 Iron]"

    return ""


func _repair_village_building() -> void:
    if not is_instance_valid(active_village_build_spot) or not active_village_build_spot.occupied:
        return

    var building = active_village_build_spot.building

    if not is_instance_valid(building):
        return

    if building.hp >= building.max_hp:
        village_build_prompt.text = "%s is already fully repaired." % building.display_name
        _show_toast("Already at full health", "info")
        return

    if wood < 1 or stone < 1:
        village_build_prompt.text = "NOT ENOUGH RESOURCES FOR REPAIR"
        _show_toast("Not enough resources to repair", "warning")
        return

    wood -= 1
    stone -= 1
    building.repair_full()

    _update_resource_ui()
    _refresh_village_management_prompt()
    _show_toast("%s repaired" % building.display_name, "success")


func _upgrade_village_building() -> void:
    if not is_instance_valid(active_village_build_spot) or not active_village_build_spot.occupied:
        return

    var building = active_village_build_spot.building

    if not is_instance_valid(building):
        return

    if not building.can_upgrade():
        village_build_prompt.text = "%s IS MAX LEVEL" % building.display_name
        _show_toast("Already at maximum level", "info")
        return

    var cost_wood: int = 0
    var cost_stone: int = 0
    var cost_iron: int = 0

    match building.building_type:
        "house":
            cost_wood = 2
            cost_stone = 1

        "farm":
            cost_wood = 2
            cost_stone = 1

        "barracks":
            cost_wood = 2
            cost_stone = 2
            cost_iron = 1

        "blacksmith":
            cost_wood = 1
            cost_stone = 1
            cost_iron = 2

    if wood < cost_wood or stone < cost_stone or iron < cost_iron:
        village_build_prompt.text = "NOT ENOUGH RESOURCES FOR UPGRADE"
        _show_toast("Not enough resources to upgrade", "warning")
        return

    wood -= cost_wood
    stone -= cost_stone
    iron -= cost_iron

    building.upgrade()

    match building.building_type:
        "house":
            population_capacity += 2

        "farm":
            farm_food_income += 2

        "barracks":
            barracks_training_bonus += 1

            for soldier in $Soldiers.get_children():
                soldier.attack_damage += 1

        "blacksmith":
            blacksmith_bonus_damage += 1
            player.apply_blacksmith_bonus(1)

            for soldier in $Soldiers.get_children():
                soldier.attack_damage += 1

    _update_resource_ui()
    _update_population_ui()
    _update_buildings_ui()
    _refresh_village_management_prompt()
    _show_toast("%s upgraded to Lv.%d" % [building.display_name, building.level], "success")


func _on_village_building_destroyed(building: GloamVillageBuilding) -> void:
    if not is_instance_valid(building):
        return

    match building.building_type:
        "house":
            houses = maxi(0, houses - 1)
            population_capacity = maxi(
                0,
                population_capacity - (3 + (building.level - 1) * 2)
            )

        "farm":
            farms = maxi(0, farms - 1)
            farm_food_income = maxi(
                0,
                farm_food_income - (3 + (building.level - 1) * 2)
            )

        "barracks":
            barracks_built = false
            barracks_training_bonus = 0

        "blacksmith":
            blacksmith_built = false

    objective_label.text = "%s was destroyed!" % building.display_name
    _show_toast("%s destroyed" % building.display_name, "danger")

    _update_population_ui()
    _update_buildings_ui()



func _update_zone_status() -> void:
    if current_phase != Phase.DAY:
        zone_label.text = "VILLAGE DEFENSE"
        return

    var p: Vector2 = player.global_position

    if p.x <= 580.0 and p.y >= 900.0:
        zone_label.text = "VILLAGE • Safe"

    elif p.x >= 600.0 and p.x <= 1350.0 and p.y >= 700.0:
        zone_label.text = "FOREST • Low Risk • Wood"

    elif p.x >= 1400.0 and p.y >= 760.0:
        zone_label.text = "MINE • Medium Risk • Stone / Iron"

    elif p.x >= 1180.0 and p.y <= 680.0:
        zone_label.text = "RUINS • High Risk • Essence"

    else:
        zone_label.text = "WILDERNESS"


func _spawn_day_enemies() -> void:
    _clear_day_enemies()

    var extra: int = maxi(0, current_day - 1)

    _spawn_day_enemy_group(
        FOREST_ENEMY_SCENE,
        forest_enemy_positions,
        mini(forest_enemy_positions.size(), 3 + extra)
    )

    _spawn_day_enemy_group(
        MINE_ENEMY_SCENE,
        mine_enemy_positions,
        mini(mine_enemy_positions.size(), 3 + extra)
    )

    _spawn_day_enemy_group(
        RUINS_ENEMY_SCENE,
        ruins_enemy_positions,
        mini(ruins_enemy_positions.size(), 2 + extra)
    )


func _spawn_day_enemy_group(scene: PackedScene, positions: Array[Vector2], count: int) -> void:
    var shuffled_positions: Array[Vector2] = []
    shuffled_positions.assign(positions)
    shuffled_positions.shuffle()

    for i in range(count):
        var enemy: GloamDayEnemy = scene.instantiate() as GloamDayEnemy
        enemy.position = shuffled_positions[i]

        if enemy.has_method("set_player"):
            enemy.set_player(player)

        $DayEnemies.add_child(enemy)


func _clear_day_enemies() -> void:
    for enemy in $DayEnemies.get_children():
        enemy.queue_free()


func grant_exploration_reward(resource_type: String, amount: int) -> void:
    match resource_type:
        "wood":
            wood += amount

        "stone":
            stone += amount

        "iron":
            iron += amount

        "food":
            food += amount

        "essence":
            essence += amount

        _:
            return

    _update_resource_ui()



func _spawn_shrine() -> void:
    var shrine: GloamShrine = SHRINE_SCENE.instantiate() as GloamShrine
    shrine.position = Vector2(1780, 360)
    $Shrines.add_child(shrine)


func set_shrine_active(active: bool) -> void:
    shrine_active = active and current_phase == Phase.DAY

    if shrine_active:
        _refresh_shrine_prompt()
        shrine_panel.show()
    else:
        shrine_panel.hide()


func _refresh_shrine_prompt() -> void:
    shrine_prompt.text = (
        "RUIN SHRINE\n"
        + "Essence: %d\n"
        + "H Mend Flesh    [1 Essence]  Full heal\n"
        + "B Wild Blessing [2 Essence]  Random elemental boon\n"
        + "E Ward Village  [3 Essence]  +35%% fortification HP tonight"
    ) % essence


func _buy_shrine_heal() -> void:
    if essence < 1:
        shrine_prompt.text = "NOT ENOUGH ESSENCE"
        _show_toast("Not enough Essence", "warning")
        return

    if player.hp >= player.max_hp:
        shrine_prompt.text = "You are already at full health."
        _show_toast("Already at full health", "info")
        return

    essence -= 1
    player.heal_full()

    _update_resource_ui()
    _refresh_shrine_prompt()
    _show_toast("Health restored", "success")


func _buy_shrine_blessing() -> void:
    if essence < 2:
        shrine_prompt.text = "NOT ENOUGH ESSENCE"
        _show_toast("Not enough Essence", "warning")
        return

    essence -= 2
    var element_name: String = player.apply_random_elemental_blessing()

    objective_label.text = "Shrine blessing gained: %s" % element_name
    _show_toast("%s blessing gained" % element_name, "success")
    _update_resource_ui()
    _refresh_shrine_prompt()


func _buy_shrine_ward() -> void:
    if essence < 3:
        shrine_prompt.text = "NOT ENOUGH ESSENCE"
        _show_toast("Not enough Essence", "warning")
        return

    if shrine_night_guard_bonus > 0:
        shrine_prompt.text = "The village is already warded for tonight."
        _show_toast("Village already warded", "info")
        return

    essence -= 3
    shrine_night_guard_bonus = 35

    objective_label.text = "The village will be warded tonight."
    _show_toast("Village warded for tonight", "success")
    _update_resource_ui()
    _refresh_shrine_prompt()


func _apply_shrine_ward_to_fortifications() -> void:
    if shrine_night_guard_bonus <= 0:
        return

    var multiplier: float = 1.0 + float(shrine_night_guard_bonus) / 100.0

    for gate in $Gates.get_children():
        if not is_instance_valid(gate):
            continue

        gate.max_hp = int(round(gate.max_hp * multiplier))
        gate.hp = gate.max_hp
        gate.health_changed.emit(gate.hp, gate.max_hp)

    for wall in $Walls.get_children():
        if not is_instance_valid(wall):
            continue

        wall.max_hp = int(round(wall.max_hp * multiplier))
        wall.hp = wall.max_hp

    shrine_night_guard_bonus = 0


func _spawn_survivors() -> void:
    _clear_survivors()

    for pos in survivor_layout:
        var survivor: GloamSurvivor = SURVIVOR_SCENE.instantiate() as GloamSurvivor
        survivor.position = pos
        $Survivors.add_child(survivor)


func _clear_survivors() -> void:
    for survivor in $Survivors.get_children():
        survivor.queue_free()


func try_rescue_villager() -> bool:
    if current_phase != Phase.DAY or game_over:
        return false

    if total_population >= population_capacity:
        objective_label.text = "Population full. Build a House."
        _show_toast("Population full. Build a House.", "warning")
        return false

    if food <= 0:
        objective_label.text = "Need 1 Food to settle a rescued villager."
        _show_toast("Need 1 Food to rescue this villager", "warning")
        return false

    food -= 1
    total_population += 1
    unassigned_villagers += 1

    _update_resource_ui()
    _update_population_ui()
    _show_toast("Villager rescued", "success")
    return true


func _assign_villager(role: String) -> void:
    if current_phase != Phase.DAY or unassigned_villagers <= 0:
        return

    match role:
        "worker":
            workers += 1
            unassigned_villagers -= 1

        "guard":
            if not barracks_built:
                objective_label.text = "Build a Barracks before training Guards."
                _show_toast("Build a Barracks first", "warning")
                return

            guards += 1
            unassigned_villagers -= 1
            _spawn_soldier("guard")

        "archer":
            if not barracks_built:
                objective_label.text = "Build a Barracks before training Archers."
                _show_toast("Build a Barracks first", "warning")
                return

            archers += 1
            unassigned_villagers -= 1
            _spawn_soldier("archer")

        _:
            return

    _update_population_ui()
    _show_toast("%s assigned" % role.to_upper(), "success")


func _spawn_soldier(role: String) -> void:
    var scene: PackedScene
    var slots: Array

    if role == "guard":
        scene = GUARD_SCENE
        slots = guard_slots
    else:
        scene = ARCHER_SOLDIER_SCENE
        slots = archer_slots

    var soldier: GloamSoldier = scene.instantiate() as GloamSoldier
    var same_role_count: int = 0

    for existing in $Soldiers.get_children():
        if existing.role == role:
            same_role_count += 1

    soldier.position = slots[same_role_count % slots.size()]

    soldier.attack_damage += blacksmith_bonus_damage
    soldier.attack_damage += barracks_training_bonus

    soldier.killed.connect(_on_soldier_killed)

    $Soldiers.add_child(soldier)


func _on_soldier_killed(role: String) -> void:
    total_population = maxi(0, total_population - 1)

    if role == "guard":
        guards = maxi(0, guards - 1)
    elif role == "archer":
        archers = maxi(0, archers - 1)

    _update_population_ui()
    _show_toast("%s lost" % role.to_upper(), "danger")


func _apply_worker_income() -> void:
    wood += workers
    stone += int(floor(workers / 2.0))
    iron += int(floor(workers / 4.0))
    food += farm_food_income

    _update_resource_ui()


func _update_population_ui() -> void:
    population_label.text = "POPULATION  %d / %d" % [total_population, population_capacity]
    unassigned_label.text = "AVAILABLE  •  %d" % unassigned_villagers
    workers_label.text = "WORKERS  •  %d" % workers
    guards_label.text = "GUARDS  •  %d" % guards
    archers_label.text = "ARCHERS  •  %d" % archers

    var can_assign: bool = current_phase == Phase.DAY and unassigned_villagers > 0 and not game_over

    assign_worker_button.disabled = not can_assign
    assign_guard_button.disabled = not can_assign or not barracks_built
    assign_archer_button.disabled = not can_assign or not barracks_built

    if unassigned_villagers <= 0:
        assign_worker_button.tooltip_text = "No available villagers to assign."
    else:
        assign_worker_button.tooltip_text = "Assign one villager as a Worker. Produces resources each dawn."

    if not barracks_built:
        assign_guard_button.tooltip_text = "Build a Barracks before training Guards."
        assign_archer_button.tooltip_text = "Build a Barracks before training Archers."
    elif unassigned_villagers <= 0:
        assign_guard_button.tooltip_text = "No available villagers to train."
        assign_archer_button.tooltip_text = "No available villagers to train."
    else:
        assign_guard_button.tooltip_text = "Train one Guard for short-range village defense."
        assign_archer_button.tooltip_text = "Train one Archer for long-range village defense."

    _refresh_button_cursor(assign_worker_button)
    _refresh_button_cursor(assign_guard_button)
    _refresh_button_cursor(assign_archer_button)


func _update_buildings_ui() -> void:
    houses_label.text = "HOUSES  •  %d   CAP %d" % [houses, population_capacity]
    farms_label.text = "FARMS  •  %d   +%d FOOD" % [farms, farm_food_income]
    barracks_label.text = "BARRACKS  •  %s" % ("READY" if barracks_built else "NONE")
    blacksmith_label.text = "BLACKSMITH  •  %s   +%d DMG" % [
        "READY" if blacksmith_built else "NONE",
        blacksmith_bonus_damage
    ]


func _spawn_day_resources() -> void:
    _clear_day_resources()

    for data in resource_layout:
        var node: GloamResourceNode = RESOURCE_NODE_SCENE.instantiate() as GloamResourceNode
        node.resource_type = data["type"]
        node.amount = 1
        node.position = data["position"]
        $Resources.add_child(node)


func _clear_day_resources() -> void:
    for node in $Resources.get_children():
        node.queue_free()


func try_collect_resource(resource_type: String, amount: int) -> bool:
    if current_phase != Phase.DAY or game_over:
        return false

    match resource_type:
        "wood":
            wood += amount
        "stone":
            stone += amount
        "iron":
            iron += amount
        _:
            return false

    _update_resource_ui()
    return true


func _update_resource_ui() -> void:
    wood_label.text = "WOOD  •  %d" % wood
    stone_label.text = "STONE  •  %d" % stone
    iron_label.text = "IRON  •  %d" % iron
    food_label.text = "FOOD  •  %d" % food
    essence_label.text = "ESSENCE  •  %d" % essence




func _choose_enemy_scene() -> PackedScene:
    var roll: float = rng.randf()

    match current_day:
        1:
            return GRUNT_SCENE

        2:
            if roll < 0.70:
                return GRUNT_SCENE
            return RUNNER_SCENE

        _:
            if roll < 0.50:
                return GRUNT_SCENE
            elif roll < 0.80:
                return RUNNER_SCENE
            return BRUTE_SCENE


func _clear_all_enemies() -> void:
    for enemy in $Enemies.get_children():
        enemy.queue_free()




func _update_xp_ui(current_xp: int, required_xp: int, current_level: int) -> void:
    level_label.text = "LEVEL %d" % current_level
    xp_label.text = "XP  %d / %d" % [current_xp, required_xp]
    xp_bar.max_value = required_xp
    xp_bar.value = current_xp


func _update_player_hp_ui(current_hp: int, max_hp: int) -> void:
    hp_label.text = "HP  %d / %d" % [current_hp, max_hp]
    hp_bar.max_value = max_hp
    hp_bar.value = current_hp


func _update_build_ui() -> void:
    weapon_label.text = "%s" % player.weapon_display_name.to_upper()
    damage_label.text = "DMG %d" % player.projectile_damage
    speed_label.text = "ATK %.2fs" % player.shot_cooldown

    if player.weapon_type == "bow":
        projectiles_label.text = "SHOT %d" % int(player.projectile_speed)
    else:
        projectiles_label.text = "MOVE %d" % int(player.move_speed)

    fire_label.text = "FIRE  •  %d" % player.fire_level
    water_label.text = "WATER  •  %d" % player.water_level
    earth_label.text = "EARTH  •  %d" % player.earth_level
    air_label.text = "AIR  •  %d" % player.air_level


func _update_core_hp_ui(current_hp: int, max_hp: int) -> void:
    core_hp_label.text = "CORE  %d / %d" % [current_hp, max_hp]
    core_hp_bar.max_value = max_hp
    core_hp_bar.value = current_hp


func _on_player_downed() -> void:
    if game_over:
        return

    downed_label.text = "DOWNED\nRespawning in %.0f seconds..." % player.respawn_delay
    downed_label.show()


func _on_player_respawned() -> void:
    downed_label.hide()


func _on_player_leveled_up(new_level: int) -> void:
    if game_over or current_phase == Phase.VICTORY:
        return

    pending_level_ups += 1

    if not level_up_panel.visible:
        _open_level_up_panel(new_level)


func _open_level_up_panel(current_level: int) -> void:
    level_up_title.text = "LEVEL %d\nCHOOSE YOUR PATH" % current_level
    _roll_upgrade_choices()

    _show_modal_dimmer()
    level_up_panel.show()
    upgrade_button_1.grab_focus()
    get_tree().paused = true


func _roll_upgrade_choices() -> void:
    current_upgrade_choices.clear()

    var indices: Array[int] = []
    for index: int in range(upgrade_pool.size()):
        indices.append(index)
    indices.shuffle()

    for i in range(3):
        current_upgrade_choices.append(upgrade_pool[indices[i]]["id"])

    _refresh_upgrade_buttons()


func _refresh_upgrade_buttons() -> void:
    var buttons: Array[Button] = [upgrade_button_1, upgrade_button_2, upgrade_button_3]

    for i in range(3):
        var data: Dictionary = _get_upgrade_data(current_upgrade_choices[i])

        var description: String = _upgrade_description_for_weapon(data)

        buttons[i].text = "%s • %s\n%s" % [
            data["element"],
            data["name"],
            description
        ]
        buttons[i].tooltip_text = description


func _upgrade_description_for_weapon(data: Dictionary) -> String:
    match data["id"]:
        "air_tailwind":
            match player.weapon_type:
                "sword":
                    return "+10% movement speed."
                "hammer":
                    return "12% faster hammer attacks."
                _:
                    return "+22% projectile speed."

        "earth_weight":
            if player.weapon_type == "hammer":
                return "+2 hammer damage and knockback."
            return "+1 damage and knockback."

        "fire_kindling":
            match player.weapon_type:
                "sword":
                    return "Sword hits burn; burns last +1 tick."
                "hammer":
                    return "Hammer hits burn for heavier ticks."
                _:
                    return "Arrows ignite enemies."

        "water_drench":
            match player.weapon_type:
                "sword":
                    return "Sword hits apply a stronger slow."
                "hammer":
                    return "Hammer hits apply longer slows."
                _:
                    return "Arrows slow enemies harder."

        _:
            return data["description"]


func _get_upgrade_data(upgrade_id: String) -> Dictionary:
    for data in upgrade_pool:
        if data["id"] == upgrade_id:
            return data

    return {}


func _choose_upgrade(index: int) -> void:
    if index < 0 or index >= current_upgrade_choices.size():
        return

    player.apply_upgrade(current_upgrade_choices[index])
    _finish_upgrade_choice()


func _finish_upgrade_choice() -> void:
    pending_level_ups -= 1
    _update_build_ui()

    if pending_level_ups > 0:
        level_up_title.text = "BONUS LEVEL\nCHOOSE YOUR PATH"
        _roll_upgrade_choices()
    else:
        level_up_panel.hide()
        _hide_modal_dimmer()
        get_tree().paused = false


func _on_village_core_destroyed() -> void:
    game_over = true

    wave_token += 1
    phase_timer.stop()

    _clear_day_resources()
    _clear_survivors()
    _clear_day_enemies()

    weapon_panel.hide()
    level_up_panel.hide()
    downed_label.hide()
    build_panel.hide()
    village_build_panel.hide()
    fortification_panel.hide()
    shrine_panel.hide()
    boss_panel.hide()

    _show_modal_dimmer()
    game_over_panel.show()
    restart_button.grab_focus()
    get_tree().paused = true


func _win_run() -> void:
    current_phase = Phase.VICTORY

    wave_token += 1
    phase_timer.stop()

    _clear_all_enemies()
    _clear_day_resources()
    _clear_survivors()
    _clear_day_enemies()

    weapon_panel.hide()
    level_up_panel.hide()
    downed_label.hide()
    build_panel.hide()
    village_build_panel.hide()
    fortification_panel.hide()
    shrine_panel.hide()
    boss_panel.hide()

    _show_modal_dimmer()
    victory_panel.show()
    victory_restart_button.grab_focus()
    get_tree().paused = true


func _restart_game() -> void:
    get_tree().paused = false
    get_tree().reload_current_scene()
